const config = require("../config/auth.config");
const db = require("../models");
const User = db.user;


exports.signup = async (req, res) => {

  const user = new User({
    email: req.body.email,
    password: req.body.password,
    name: req.body.name
  });
  
  try {
    const usercreated = await user.save();

    res.status(200).send({
      name: usercreated.name
    });
  } catch (err) {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }
  }
};

exports.getAll = async (req,res) => {
  try {
    var data = await User.find({})
    res.send(data);
  } catch (err) {
    res.status(500).send({
      message:
        err.message || "Some error occurred while retrieving tutorials."
    });
  }
    
    
}



exports.deleteUser = async (req, res) => {
  try {
    await User.findOneAndRemove({
      email: req.body.email
    });
    res.status(200).send({
      message: "User deleted"
    });
  } catch (err) {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }
  }
    

     
  };

  exports.updateUser = async(req, res) => {
    try {
      console.log(req.body.name);
      await User.findOneAndUpdate({
        email: req.body.email
      },{
        email: req.body.email,
        password: req.body.password,
        name: req.body.name
      });
      res.status(200).send({
        message: "User Updated",
        name: req.body.name,
      });
    } catch (err) {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
    }
    
      
  };