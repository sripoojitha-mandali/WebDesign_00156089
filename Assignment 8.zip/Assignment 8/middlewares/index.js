const verifySignUp = require("./verifySignUp");

module.exports = {
  verifySignUp
};