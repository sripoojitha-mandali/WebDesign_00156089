const db = require("../models");
const { validate } = require("../models/user.model");
const ROLES = db.ROLES;
const User = db.user;



function isPasswordValid(password) {
    if (!password)
        return false;

    if(password.length<8)
        return false;

    

   

    return true;
}
function isEmailValid(email) {
    if (!email)
        return false;

    

    return true;
}

checkUpdate = async (req, res, next) => {
  try {
    const user = await User.findOne({
      email: req.body.email
    });
      next();

    
  } catch (err) {
    console.log(err);
    // if (err) {
      res.status(400).send({ message: "Failed! User doesn't exist" });
      return;
    // }

  }
  
  };
  

checkValidate = async (req, res, next) => {
  try {
    const user  = await User.findOne({
      email: req.body.email
    });
    if (user) {
      res.status(400).send({ message: "Failed! Email is already in use!" });
      return;
    }
    if(req.body.email==null ) {
      res.status(400).send({ message: "Failed! Email is not valid" });
      return;
    }
    if(req.body.name == null ) {
      res.status(400).send({ message: "Failed! Name of user is not valid" });
      return;
    }
    if(req.body.password==null ) {
      res.status(400).send({ message: "Failed! Password is not valid" });
      return;
    }
    next();
  } catch(err) {
    // if (err) {
      res.status(500).send({ message: err });
    // }
  }
  
};



const verifySignUp = {
  checkValidate,
  checkUpdate,
  checkExist
};

module.exports = verifySignUp;